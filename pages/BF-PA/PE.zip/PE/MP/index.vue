<template>
  <div>
    <LayoutsBreadcrumb :items="breadcrumb" />

    <rs-card class="mt-4">
      <template #header>
        <div class="flex justify-between items-center">
          <h2 class="text-xl font-semibold">Senarai Mesyuarat & Program</h2>
          <rs-button
            variant="primary-outline"
            size="sm"
            icon="material-symbols:filter-alt-outline"
            @click="toggleFilter"
          >
            Filter
          </rs-button>
        </div>
      </template>

      <template #body>
        <div class="p-4">
          <!-- 🔔 Notifikasi Alert -->
          <div
            v-if="hasNewApplications"
            class="mb-4 p-4 bg-indigo-100 border border-indigo-300 text-indigo-800 rounded-md flex items-center space-x-2"
          >
            <Icon name="heroicons:exclamation-circle" class="text-indigo-600" size="20" />
            <span>
              📢 <strong>Ada program baharu</strong> yang perlu disemak hari ini.
            </span>
          </div>

          <!-- Carian & Penapis -->
          <div v-if="showFilter" class="mb-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormKit
                type="text"
                name="search"
                placeholder="Cari ID atau Nama Program"
                :value="searchQuery"
                @input="handleSearch"
              />
              <FormKit
                type="select"
                name="status"
                placeholder="Status"
                :options="statusOptions"
                :value="selectedStatus"
                @input="handleStatusChange"
              />
            </div>
          </div>

          <!-- Jadual Mesyuarat/Program -->
          <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
              <thead class="bg-gray-50">
                <tr>
                  <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID Rujukan</th>
                  <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nama Program / Mesyuarat</th>
                  <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tarikh</th>
                  <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                  <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tindakan</th>
                </tr>
              </thead>
              <tbody class="bg-white divide-y divide-gray-200">
                <tr v-for="activity in filteredActivities" :key="activity.id">
                  <td class="px-6 py-4">{{ activity.id }}</td>
                  <td class="px-6 py-4">{{ activity.name }}</td>
                  <td class="px-6 py-4">{{ activity.date }}</td>
                  <td class="px-6 py-4">
                    <span class="px-2 py-1 text-xs font-medium rounded-full" :class="getStatusColor(activity.statusSemakan)">
                      {{ activity.statusSemakan }}
                    </span>
                  </td>
                  <td class="px-6 py-4 text-right">
                    <rs-button variant="primary" size="sm" @click="navigateTo(getActionRoute(activity))">
                      {{ getActionButtonText(activity.statusSemakan) }}
                    </rs-button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </template>
    </rs-card>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'
import { isToday, parseISO } from 'date-fns'

const router = useRouter()

const breadcrumb = ref([
  { name: "Pengurusan Elaun", type: "link", path: "/BF-PA/PE/MP" },
  { name: "Mesyuarat/Program", type: "current", path: "/BF-PA/PE/MP/mesyuarat" }
])

const showFilter = ref(false)
const toggleFilter = () => { showFilter.value = !showFilter.value }

const statusOptions = [
  { label: 'Semua', value: '' },
  { label: 'PERLU DISEMAK (BARU)', value: 'PERLU DISEMAK (BARU)' },
  { label: 'PERLU DISEMAK', value: 'PERLU DISEMAK' },
  { label: 'DILULUSKAN', value: 'DILULUSKAN' },
  { label: 'DITOLAK', value: 'DITOLAK' },
  { label: 'PERLU DIKEMASKINI SEMULA', value: 'PERLU DIKEMASKINI SEMULA' },
  { label: 'SEDANG MENUNGGU PROSES UNTUK BAYARAN', value: 'SEDANG MENUNGGU PROSES UNTUK BAYARAN' }
]

const searchQuery = ref('')
const selectedStatus = ref('')

const generateRandomID = () => `MP/${new Date().getFullYear()}/${Math.floor(1000 + Math.random() * 9000)}`

const activitiesRaw = ref([
  { id: generateRandomID(), name: 'Mesyuarat JPPA Bil 5/2025', date: '2025-07-31', status: 'PERLU DISEMAK' },
  { id: generateRandomID(), name: 'Program Tazkirah Perdana 2025', date: '2025-07-29', status: 'DILULUSKAN' },
  { id: generateRandomID(), name: 'Bengkel Teknikal Penyelarasan', date: '2025-07-28', status: 'PERLU DIKEMASKINI SEMULA' },
  { id: generateRandomID(), name: 'Retreat JK Zakat Negeri', date: '2025-07-26', status: 'PERLU DISEMAK' }
])

const activities = computed(() =>
  activitiesRaw.value.map(a => ({
    ...a,
    statusSemakan: a.status === 'PERLU DISEMAK' && isToday(parseISO(a.date)) ? 'PERLU DISEMAK (BARU)' : a.status
  }))
)

const hasNewApplications = computed(() =>
  activities.value.some(a => a.statusSemakan === 'PERLU DISEMAK (BARU)')
)

const filteredActivities = computed(() => {
  return activities.value.filter(a => {
    const matchSearch = !searchQuery.value || a.name.toLowerCase().includes(searchQuery.value.toLowerCase()) || a.id.toLowerCase().includes(searchQuery.value.toLowerCase())
    const matchStatus = !selectedStatus.value || a.statusSemakan === selectedStatus.value
    return matchSearch && matchStatus
  })
})

const getStatusColor = (status) => {
  switch (status) {
    case 'PERLU DISEMAK (BARU)': return 'bg-indigo-100 text-indigo-800'
    case 'PERLU DISEMAK': return 'bg-yellow-100 text-yellow-800'
    case 'DILULUSKAN': return 'bg-green-100 text-green-800'
    case 'DITOLAK': return 'bg-red-100 text-red-800'
    case 'PERLU DIKEMASKINI SEMULA': return 'bg-orange-100 text-orange-800'
    case 'SEDANG MENUNGGU PROSES UNTUK BAYARAN': return 'bg-blue-100 text-blue-800'
    default: return 'bg-gray-100 text-gray-800'
  }
}

const getActionRoute = (activity) => {
  if (activity.status.includes('PERLU DISEMAK')) return '/BF-PA/PE/MP/03'
  if (activity.status === 'DILULUSKAN') return '/BF-PA/PE/MP/06'
  if (activity.status === 'PERLU DIKEMASKINI SEMULA') return '/BF-PA/PE/MP/07'
  return '#'
}

const getActionButtonText = (status) => {
  if (status.includes('PERLU DISEMAK')) return 'Semak'
  if (status === 'DILULUSKAN') return 'Lihat'
  if (status === 'DITOLAK') return 'Lihat'
  if (status === 'PERLU DIKEMASKINI SEMULA') return 'Kemaskini'
  if (status === 'SEDANG MENUNGGU PROSES UNTUK BAYARAN') return 'Urus Bayaran'
  return 'Lihat'
}

const handleSearch = (e) => { searchQuery.value = e.target.value }
const handleStatusChange = (e) => { selectedStatus.value = e.target.value }
</script>
