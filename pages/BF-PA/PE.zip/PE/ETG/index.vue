<template>
  <div>
    <rs-card>
      <template #header>
        <h2 class="text-lg font-semibold">Senarai Elaun Tugasan</h2>
      </template>

      <template #body>
        <!-- Filter -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
          <FormKit type="select" label="Tahun" :options="tahunOptions" v-model="selectedTahun" />
          <FormKit type="select" label="Jenis Elaun" :options="jenisElaunOptions" v-model="selectedElaun" />
          <FormKit type="select" label="Kategori PA" :options="kategoriOptions" v-model="selectedKategori" />
          <rs-button class="mt-6" @click="papar = true">Cari</rs-button>
        </div>

        <!-- Jadual Elaun Tugasan -->
        <div v-if="papar" class="overflow-x-auto">
          <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-100">
              <tr>
                <th class="px-4 py-2">#</th>
                <th class="px-4 py-2">Jenis Elaun</th>
                <th class="px-4 py-2">Kategori PA</th>
                <th class="px-4 py-2">Amaun (RM)</th>
                <th class="px-4 py-2">Kod Bajet</th>
                <th class="px-4 py-2 text-center">Tindakan</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(item, index) in filteredElaun" :key="index">
                <td class="px-4 py-2">{{ index + 1 }}</td>
                <td class="px-4 py-2">{{ item.jenisElaun }}</td>
                <td class="px-4 py-2">{{ item.kategori }}</td>
                <td class="px-4 py-2">{{ item.amaun }}</td>
                <td class="px-4 py-2">{{ item.kodBajet }}</td>
                <td class="px-4 py-2 text-center">
                  <rs-button size="sm" @click="bukaSenaraiPenerima(item)">Senarai Penerima</rs-button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </template>
    </rs-card>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()

const selectedTahun = ref('')
const selectedElaun = ref('')
const selectedKategori = ref('')
const papar = ref(false)

const tahunOptions = [
  { label: '2025', value: '2025' },
  { label: '2024', value: '2024' }
]

const jenisElaunOptions = [
  { label: 'BANCIAN BARU : PER BORANG PERMOHONAN', value: 'BANCIAN BARU : PER BORANG PERMOHONAN' },
  { label: 'KEMASKINI : PER BORANG PERMOHONAN', value: 'KEMASKINI : PER BORANG PERMOHONAN' },
  { label: 'PERMOHONAN BANTUAN : PER BORANG PERMOHONAN', value: 'PERMOHONAN BANTUAN : PER BORANG PERMOHONAN' }
]

const kategoriOptions = [
  { label: 'PAK', value: 'PAK' },
  { label: 'PAK+', value: 'PAK+' }
]

// Data berdasarkan imej & teks anda
const senaraiElaun = ref([
  { jenisElaun: 'BANCIAN BARU : PER BORANG PERMOHONAN', kategori: 'PAK', amaun: 30, kodBajet: 'B34106', tahun: '2025' },
  { jenisElaun: 'KEMASKINI : PER BORANG PERMOHONAN', kategori: 'PAK', amaun: 20, kodBajet: 'B34106', tahun: '2025' },
  { jenisElaun: 'PERMOHONAN BANTUAN : PER BORANG PERMOHONAN', kategori: 'PAK', amaun: 20, kodBajet: 'B34106', tahun: '2025' },
  { jenisElaun: 'BANCIAN BARU : PER BORANG PERMOHONAN', kategori: 'PAK+', amaun: 30, kodBajet: 'B34106', tahun: '2025' },
  { jenisElaun: 'KEMASKINI : PER BORANG PERMOHONAN', kategori: 'PAK+', amaun: 20, kodBajet: 'B34106', tahun: '2025' },
  { jenisElaun: 'PERMOHONAN BANTUAN : PER BORANG PERMOHONAN', kategori: 'PAK+', amaun: 20, kodBajet: 'B34106', tahun: '2025' }
])

const filteredElaun = computed(() =>
  senaraiElaun.value.filter(e =>
    (!selectedTahun.value || e.tahun === selectedTahun.value) &&
    (!selectedElaun.value || e.jenisElaun === selectedElaun.value) &&
    (!selectedKategori.value || e.kategori === selectedKategori.value)
  )
)

const bukaSenaraiPenerima = (item) => {
  router.push({
    path: '/BF-PA/PE/MP/AB/penerima',
    query: {
      elaun: item.jenisElaun,
      kategori: item.kategori,
      tahun: selectedTahun.value
    }
  })
}
</script>
