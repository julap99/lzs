<template>
  <div>
    <rs-card>
      <template #header>
        <h2 class="text-lg font-semibold">Senarai Elaun Tahunan</h2>
      </template>

      <template #body>
        <!-- Penapis -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <FormKit type="select" label="Tahun" :options="tahunOptions" v-model="selectedTahun" />
          <FormKit type="select" label="Nama Elaun" :options="elaunOptions" v-model="selectedElaun" />
          <FormKit type="select" label="Kategori PA" :options="kategoriOptions" v-model="selectedKategori" />
          <rs-button class="mt-6" @click="filterElaun">Cari / Papar Senarai</rs-button>
        </div>

        <!-- Jadual Elaun (dipaparkan hanya selepas filter) -->
        <div v-if="paparSenarai && filteredElaun.length > 0" class="overflow-x-auto">
          <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-100">
              <tr>
                <th class="px-4 py-2">#</th>
                <th class="px-4 py-2">Tahun</th>
                <th class="px-4 py-2">Nama Elaun</th>
                <th class="px-4 py-2">Kategori PA</th>
                <th class="px-4 py-2">Amaun (RM)</th>
                <th class="px-4 py-2">Kod Bajet</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(item, index) in filteredElaun" :key="index">
                <td class="px-4 py-2">{{ index + 1 }}</td>
                <td class="px-4 py-2">{{ item.tahun }}</td>
                <td class="px-4 py-2">{{ item.nama }}</td>
                <td class="px-4 py-2">{{ item.kategori }}</td>
                <td class="px-4 py-2">{{ item.amaun }}</td>
                <td class="px-4 py-2">{{ item.kodBajet }}</td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- Notifikasi jika tiada data -->
        <div v-else-if="paparSenarai && filteredElaun.length === 0" class="text-center text-gray-500 py-6">
          Tiada data padan untuk kriteria carian.
        </div>
      </template>
    </rs-card>
  </div>
</template>

<script setup>
import { ref } from 'vue'

// Pilihan dropdown
const tahunOptions = [
  { label: '2025', value: '2025' },
  { label: '2024', value: '2024' },
  { label: '2023', value: '2023' }
]

const elaunOptions = [
  { label: 'KHAS - 48 AKTIVITI/TAHUN', value: 'KHAS - 48 AKTIVITI/TAHUN' },
  { label: 'TAHUNAN KETUA PENOLONG AMIL', value: 'TAHUNAN KETUA PENOLONG AMIL' },
  { label: 'ANUGERAH KETUA PENOLONG AMIL TERBAIK', value: 'ANUGERAH KETUA PENOLONG AMIL TERBAIK' },
  { label: 'ANUGERAH PENOLONG AMIL TERBAIK', value: 'ANUGERAH PENOLONG AMIL TERBAIK' }
]

const kategoriOptions = [
  { label: 'PAK', value: 'PAK' },
  { label: 'PAF', value: 'PAF' },
  { label: 'PAP', value: 'PAP' },
  { label: 'PAK+', value: 'PAK+' }
]

const selectedTahun = ref('')
const selectedElaun = ref('')
const selectedKategori = ref('')
const paparSenarai = ref(false)

const semuaElaun = [
  { tahun: '2025', nama: 'KHAS - 48 AKTIVITI/TAHUN', kategori: 'PAK', amaun: 400, kodBajet: 'B31702' },
  { tahun: '2025', nama: 'KHAS - 48 AKTIVITI/TAHUN', kategori: 'PAK+', amaun: 400, kodBajet: 'B31702' },
  { tahun: '2025', nama: 'TAHUNAN KETUA PENOLONG AMIL', kategori: 'PAK', amaun: 500, kodBajet: 'B31702' },
  { tahun: '2025', nama: 'TAHUNAN KETUA PENOLONG AMIL', kategori: 'PAF', amaun: 300, kodBajet: 'B31702' },
  { tahun: '2025', nama: 'ANUGERAH KETUA PENOLONG AMIL TERBAIK', kategori: 'PAK', amaun: 750, kodBajet: 'B31702' },
  { tahun: '2025', nama: 'ANUGERAH KETUA PENOLONG AMIL TERBAIK', kategori: 'PAF', amaun: 750, kodBajet: 'B31702' },
  { tahun: '2025', nama: 'ANUGERAH PENOLONG AMIL TERBAIK', kategori: 'PAK', amaun: 400, kodBajet: 'B31702' },
  { tahun: '2025', nama: 'ANUGERAH PENOLONG AMIL TERBAIK', kategori: 'PAF', amaun: 400, kodBajet: 'B31702' },
  { tahun: '2025', nama: 'ANUGERAH PENOLONG AMIL TERBAIK', kategori: 'PAP', amaun: 400, kodBajet: 'B31702' },
  { tahun: '2025', nama: 'ANUGERAH PENOLONG AMIL TERBAIK', kategori: 'PAK+', amaun: 400, kodBajet: 'B31702' }
]

const filteredElaun = ref([])

const filterElaun = () => {
  filteredElaun.value = semuaElaun.filter(e =>
    (!selectedTahun.value || e.tahun === selectedTahun.value) &&
    (!selectedElaun.value || e.nama === selectedElaun.value) &&
    (!selectedKategori.value || e.kategori === selectedKategori.value)
  )
  paparSenarai.value = true
}
</script>
