<template>
  <div>
    <rs-card>
      <template #header>
        <h2 class="text-lg font-semibold">Senarai Elaun Tahunan</h2>
      </template>

      <template #body>
        <!-- Filter -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
          <FormKit type="select" label="Tahun" :options="tahunOptions" v-model="selectedTahun" />
          <FormKit type="select" label="Nama Elaun" :options="namaElaunOptions" v-model="selectedNamaElaun" />
          <FormKit type="select" label="Kategori PA" :options="kategoriOptions" v-model="selectedKategori" />
          <rs-button class="mt-6" @click="papar = true">Cari</rs-button>
        </div>

        <!-- Jadual Senarai Elaun -->
        <div v-if="papar" class="overflow-x-auto">
          <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-100">
              <tr>
                <th class="px-4 py-2">#</th>
                <th class="px-4 py-2">Nama Elaun</th>
                <th class="px-4 py-2">Kategori PA</th>
                <th class="px-4 py-2">Amaun (RM)</th>
                <th class="px-4 py-2">Kod Bajet</th>
                <th class="px-4 py-2 text-center">Tindakan</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(item, index) in filteredElaun" :key="index">
                <td class="px-4 py-2">{{ index + 1 }}</td>
                <td class="px-4 py-2">{{ item.namaElaun }}</td>
                <td class="px-4 py-2">{{ item.kategori }}</td>
                <td class="px-4 py-2">{{ item.amaun }}</td>
                <td class="px-4 py-2">{{ item.kodBajet }}</td>
                <td class="px-4 py-2 text-center">
                  <rs-button size="sm" @click="bukaSenaraiPenerima(item)">
                    Senarai Penerima
                  </rs-button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </template>
    </rs-card>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()

// FILTER STATES
const selectedTahun = ref('')
const selectedNamaElaun = ref('')
const selectedKategori = ref('')
const papar = ref(false)

// OPTIONS
const tahunOptions = [
  { label: '2025', value: '2025' },
  { label: '2024', value: '2024' },
  { label: '2023', value: '2023' }
]

const namaElaunOptions = [
  { label: 'KHAS - 48 AKTIVITI/TAHUN', value: 'KHAS - 48 AKTIVITI/TAHUN' },
  { label: 'TAHUNAN KETUA PENOLONG AMIL', value: 'TAHUNAN KETUA PENOLONG AMIL' },
  { label: 'ANUGERAH KETUA PENOLONG AMIL TERBAIK', value: 'ANUGERAH KETUA PENOLONG AMIL TERBAIK' },
  { label: 'ANUGERAH PENOLONG AMIL TERBAIK', value: 'ANUGERAH PENOLONG AMIL TERBAIK' }
]

const kategoriOptions = [
  { label: 'PAK', value: 'PAK' },
  { label: 'PAF', value: 'PAF' },
  { label: 'PAP', value: 'PAP' },
  { label: 'PAK+', value: 'PAK+' }
]

// DUMMY DATA
const senaraiElaun = ref([
  { namaElaun: 'KHAS - 48 AKTIVITI/TAHUN', kategori: 'PAK', amaun: 400, kodBajet: 'B31702', tahun: '2025' },
  { namaElaun: 'KHAS - 48 AKTIVITI/TAHUN', kategori: 'PAK+', amaun: 400, kodBajet: 'B31702', tahun: '2025' },
  { namaElaun: 'TAHUNAN KETUA PENOLONG AMIL', kategori: 'PAK', amaun: 500, kodBajet: 'B31702', tahun: '2025' },
  { namaElaun: 'TAHUNAN KETUA PENOLONG AMIL', kategori: 'PAF', amaun: 300, kodBajet: 'B31702', tahun: '2025' },
  { namaElaun: 'ANUGERAH KETUA PENOLONG AMIL TERBAIK', kategori: 'PAK', amaun: 750, kodBajet: 'B31702', tahun: '2025' },
  { namaElaun: 'ANUGERAH KETUA PENOLONG AMIL TERBAIK', kategori: 'PAF', amaun: 750, kodBajet: 'B31702', tahun: '2025' },
  { namaElaun: 'ANUGERAH PENOLONG AMIL TERBAIK', kategori: 'PAK', amaun: 400, kodBajet: 'B31702', tahun: '2025' },
  { namaElaun: 'ANUGERAH PENOLONG AMIL TERBAIK', kategori: 'PAF', amaun: 400, kodBajet: 'B31702', tahun: '2025' },
  { namaElaun: 'ANUGERAH PENOLONG AMIL TERBAIK', kategori: 'PAP', amaun: 400, kodBajet: 'B31702', tahun: '2025' },
  { namaElaun: 'ANUGERAH PENOLONG AMIL TERBAIK', kategori: 'PAK+', amaun: 400, kodBajet: 'B31702', tahun: '2025' }
])

// FILTERED DATA
const filteredElaun = computed(() =>
  senaraiElaun.value.filter(e =>
    (!selectedTahun.value || e.tahun === selectedTahun.value) &&
    (!selectedNamaElaun.value || e.namaElaun === selectedNamaElaun.value) &&
    (!selectedKategori.value || e.kategori === selectedKategori.value)
  )
)

// ARAH KE SENARAI PENERIMA
const bukaSenaraiPenerima = (item) => {
  router.push({
    path: '/BF-PA/PE/MP/ET/tugasan',
    query: {
      elaun: item.namaElaun,
      kategori: item.kategori,
      tahun: selectedTahun.value
    }
  })
}
</script>
